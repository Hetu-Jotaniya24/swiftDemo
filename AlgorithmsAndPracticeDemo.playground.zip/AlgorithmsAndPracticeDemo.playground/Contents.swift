import UIKit


//MARK: --------- FIZZBUZZ Algo ---------

func fizz_buzzAlgo(arr:[Int]) {
    
    for item in arr{
        if item % 3 == 0 && item % 5 == 0{
           print("\(item) fizz-buzz")
        }else if item % 3 == 0 {
            print("\(item) fizz")
        }else if item % 5 == 0 {
            print("\(item) buzz")
        }
    }
   
}

//fizz_buzzAlgo(arr: [1,2,3,5,6,7,8,10,20,25,30])

//MARK: --------- Factorial Number ---------

func factorialNumber(value:UInt) -> UInt {
    if value == 0 {
        return 1
    }
    var result : UInt = 1
    for i in 1...value{
        result = result * i
    }
     
    return result
}

func recursiveFactorial(value:UInt) -> UInt{
    if value == 0 {
        return 1
    }
    return value * recursiveFactorial(value: value - 1)
}

//factorialNumber(value: 5)
//recursiveFactorial(value: 5)

//MARK: --------- Linear and Binary Search ---------

func linearSearch(searchValue : Int , arraySearch : [Int]) -> Bool {
    arraySearch.contains { return $0 == searchValue ? true : false }
}

linearSearch(searchValue: 20, arraySearch: [1,2,3,5,6,7,8,10,20,25,30])

func binarySearch(searchValue : Int , arraySearch : [Int]) -> Bool {
//    arraySearch.sorted()
    var firstIndex = 0
    var lastIndex = arraySearch.count - 1
    
    while firstIndex <= lastIndex {
        let midIndex = (firstIndex + lastIndex) / 2
        let midValue = arraySearch[midIndex]
        
        print("midValue \(midValue) , firstIndex \(firstIndex), lastIndex \(lastIndex) , \(arraySearch[firstIndex]) , \(arraySearch[lastIndex])")
        
        if midValue == searchValue {
            return true
        }
        
        if searchValue < midValue{
            lastIndex = midIndex - 1
        }
        
        if searchValue > midIndex {
            firstIndex = midIndex + 1
        }
        
    }
    return false
}
binarySearch(searchValue: 2, arraySearch: [1,2,3,5,6,7,8,10,20,25,30])


//MARK: --------- Fibonacci Sequence ---------

func fibonacciSequence(num : Int) -> [Int] {
    if num <= 1{
        return [0,1]
    }
    var arraySequence = [0,1]

    for _ in 0...num - 2 {
        let first = arraySequence[arraySequence.count - 2]
        let last = arraySequence.last!
        print("first \(first), last \(last)")
        arraySequence.append(first + last)
    }
    return arraySequence
}
//0,1,1,2,3,5
print(fibonacciSequence(num: 9))

//MARK: --------- Reverse Words ---------

func reverseString(stringToRevert : String) -> String{
    ///Will reverse words as well chars
//    reduce("") { String($1) + String($0) }
//    String(stringToRevert.reversed())
    
    let reversed = stringToRevert.components(separatedBy: " ").enumerated().map{ String($1.reversed())}
    return reversed.joined(separator: " ")
}
print(reverseString(stringToRevert: "Hello..! How are you!"))

//MARK: --------- Binary Tree Search ---------

class Node {
    let value: Int
    var leftChild: Node?
    var rightChild: Node?
    
    init( value: Int, leftChild: Node?, rightChild: Node?) {
        self.value = value
        self.leftChild = leftChild
        self.rightChild = rightChild
    }
}

//left branch
let oneNode = Node( value: 1, leftChild: nil, rightChild: nil)
let fiveNode = Node(value: 5, leftChild: oneNode, rightChild: nil)

//right branch
let elevenNode = Node(value: 11, leftChild: nil, rightChild: nil)
let twentyNode = Node(value: 20, leftChild: nil, rightChild: nil)
let fourteenNode = Node(value: 14, leftChild: elevenNode, rightChild: twentyNode)

let tenRootNode = Node(value: 10, leftChild: fiveNode, rightChild: fourteenNode)

//          10
//         /  \
//        5    14
//       /    /  \
//      1    11   20
//The values of left branch will always smaller than root node and vice versa in binary tree

func search(node: Node?, searchValue: Int) -> Bool {
    if node == nil {
        return false
    }
    if node?.value == searchValue {
        return true
    } else if searchValue < node!.value {
        return search(node: node?.leftChild, searchValue: searchValue)
    } else {
        return search(node: node?.rightChild, searchValue: searchValue)
    }
}

search(node: tenRootNode, searchValue: 20)

//MARK: --------- Abstract Syntax Tree ---------

class abstractNode {
    var operation : String?
    let value: Float?
    var leftChild: abstractNode?
    var rightChild: abstractNode?
    
    init(operation: String?, value: Float?, leftChild: abstractNode?, rightChild: abstractNode?) {
        self.value = value
        self.operation = operation
        self.leftChild = leftChild
        self.rightChild = rightChild
    }
}




//Ex : 25 * 6 + 5
25 * 6 + 5
//Algo should return 155
//Represent the equation above in the tree
//          '+'
//         /   \
//        '*'   5
//       /  \
//      25   6

let rootPlusNode = abstractNode(operation: "+" ,value: nil, leftChild: multTwentyFive_SixNode, rightChild: abstractFiveNode)

let multTwentyFive_SixNode = abstractNode(operation: "*" ,value: nil, leftChild: abstractTwentyFiveNode, rightChild: abstractSixNode)
let abstractSixNode = abstractNode(operation: nil ,value: 6, leftChild: nil, rightChild: nil)
let abstractTwentyFiveNode = abstractNode(operation: nil ,value: 25, leftChild: nil, rightChild: nil)

let abstractFiveNode = abstractNode(operation: nil ,value: 5, leftChild: nil, rightChild: nil)


func evaluate(keyNode : abstractNode) -> Float {
    if keyNode.value != nil{
        return keyNode.value!
    }
    guard let leftNode = keyNode.leftChild else { return 0}
    guard let rightNode = keyNode.rightChild else { return 0}
    if keyNode.operation == "+"{
        return evaluate(keyNode: leftNode) + evaluate(keyNode:rightNode)
    }else if keyNode.operation == "-"{
        return evaluate(keyNode: leftNode) - evaluate(keyNode:rightNode)
    }else if keyNode.operation == "*"{
        return evaluate(keyNode: leftNode) * evaluate(keyNode:rightNode)
    }else if keyNode.operation == "/"{
        return evaluate(keyNode: leftNode) / evaluate(keyNode:rightNode)
    }
    return 0
}

print(evaluate(keyNode: rootPlusNode))


//MARK: ---------  Linked List - Reverse the list  ---------


class LinkedNode {
    let value : Int
    var next : LinkedNode?
    
    init(value:Int, next : LinkedNode?){
        self.value = value
        self.next = next
    }
}
let threeNode = LinkedNode(value: 3, next: nil)
let twoNode = LinkedNode(value: 2, next: threeNode)
let firstNode = LinkedNode(value: 1, next: twoNode)

//Current list = 1->2->3->nil
//nil<-1->2->3->nil
//nil<-1<-2->3->nil

// nil<-1<-2<-3
//Output : 3->2->1->nil

func printList(head:LinkedNode?){
    var currentNode = head
    while currentNode != nil{
        print(currentNode?.value ?? -1)
        currentNode = currentNode?.next
    }
}

func reverseTheList(head:LinkedNode?) -> LinkedNode? {
    
    var currentNode = head
    var next : LinkedNode?
    var prev : LinkedNode?
    
    while currentNode != nil{
     
        next = currentNode?.next
        currentNode?.next = prev
        prev = currentNode
        currentNode = next
//        print("current \(currentNode?.value), prev \(prev?.value), next \(next?.value)")
    }
    
    return prev
}
printList(head: reverseTheList(head: firstNode))

//MARK: --------- Palindrome Number ---------

func palindromeNumber(str:String) -> [String:Int] {
    
    let strArray = str.components(separatedBy: " ")
    var dict : [String:Int] = [:]
    
    strArray.forEach { word in
//        print(String(word.reversed()))
        if (String(word.reversed())) == word {
//            print(String(word.reversed()),word)
            if dict.keys.contains(word){
                dict[word]! += 1
            }else{
                dict[word] = 1
            }
        }
    }
    return dict
}
 
print(palindromeNumber(str: "madam anna kayak notpalindrome anna civic racecar racecar madam"))
